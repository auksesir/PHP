SELECT COUNT(moduleResult) as countMarks 
FROM ubihol01db.moduleResults
WHERE moduleCode = 'dt';