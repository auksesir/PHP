<?php

class Navigation {

    public $content = '';

    # defining navigation bar
    public function definingNav($pdo) {

	if (isset($_SESSION['uName']) AND (isset($_SESSION['passw']))) {
		$nav['moduleResults'] = 'Module Results';
        $userType = userType($_SESSION['uName'], $pdo);
        if ($userType == "error") {
            $this -> content .= htmlParagraph("ERROR user type of the logged in user could not be found.", False);
        }
        if ($userType == "True") { # only admins can access this page
            $nav['userAdmin'] = 'User Administration';
            }
        return [$nav, $this -> content];		
    }
    }
        
    public function gettingFile($pdo, $nav) {
        # getting the view
        if (!isset($_GET['view'])) { 
            $i = 'home'; # display default landing view
        } else {
            $i = $_GET['view']; # else get requested view
        }

        # if logged in admin user was changed to academic user
        if ((isset($_SESSION['uName'])) and (userType($_SESSION['uName'], $pdo) == 'False') and ($i == 'userAdmin')) { 
            $i = 'home'; # display default landing view
        }
        
        # choosing which file to display
        if (isset($nav[$i])) { 
			$headTitle = $nav[$i]; 
			$file = 'views/' . $i . '.php'; 
			if (file_exists($file)) { 	
			} else { # selected view file not found - report error
				$headTitle = "ERROR";
				$this -> content = htmlParagraph("404 error - $file not found!", False);
			}
		} else {
			$headTitle = "ERROR";
			$file =  'views/404.php'; # $id not valid, POTENTIAL user hack report error
		}
        return [$headTitle, $this -> content, $file];
    }
}
?>