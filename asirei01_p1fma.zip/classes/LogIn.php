<?php

class LogIn {

    # if log in button is pressed
    public static function loginForm($pdo) {
        $formPlaceholders = clearErrorLoginFormPlaceholders();	
        #data in $_POST to be checked
	    $formData = validateLoginData($_POST, $pdo, $formPlaceholders); 
        $errors = $formData[0];
        $formPlaceholders = $formData[1]; 
        
        # if log in name or password are incorrect
        if (!empty($errors)) {    
            #replace all placeholders with their values
            $form = formOutput($formPlaceholders, 'html/loginForm.html');
            return $form;
        } else {# if log in name and password are correct
                $_SESSION['uName'] = $_POST['uName'];
                $_SESSION['passw'] = $_POST['password'];
                	
        }
    }

    # before log in button is pressed
    public static function emptyLogin() {
        $formPlaceholders = clearErrorLoginFormPlaceholders();
        $form = formOutput($formPlaceholders, 'html/loginForm.html');
        return $form;
    }

    # returns log out form after successful log in
    public static function loggedIn($pdo) { 
        $name = userFullName($_SESSION['uName'], $pdo); 
        $userFullName = checkFullName($name); # checking if no error was returned
        $fullNameLoggedIn = $userFullName[0];
        $content = $userFullName[1];
        if ($content == '') { # if no error was returned
            $placeHolders[] = '[+fullName+]'; 
            $form = htmlTemplate($placeHolders, $fullNameLoggedIn, 'html/logoutForm.html');
        } else {
            $form = htmlTemplate($placeHolders, $content, 'html/logoutForm.html');
        }
        return $form;
    }

    # when log out button is pressed
    public static function logOut() {

        if (isset($_POST['logout'])) {
            $_SESSION = array(); # $_SESSION values deleted
            if (ini_get("session.use_cookies")) {
                $yesterday = time() - (24 * 60 * 60);
                $params = session_get_cookie_params();
                setcookie(session_name(), '', $yesterday,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]);
            }
            session_destroy(); # session is terminated
            # returning to home page after each log out
            header('Location: '.$_SERVER['PHP_SELF'].'?view=home'); 
        }
    }
}
?>