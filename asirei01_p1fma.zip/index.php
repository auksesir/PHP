<?php

require_once 'includes/functions.php';  # user defined functions
require_once 'includes/config.php';  # database configuration datas
spl_autoload_register('myAutoloader');

session_start(); # starting he session

$headTitle = 'ERROR'; # if view file not found error message is displayed
$viewHeading = 'ERROR';
$form = ''; # log in; log out form
$nav = array();  # navigation
$nav['home'] = 'Home Page';

if ($databaseConnected) { # if database connected
	$admin = [
		'fName' => 'Admin',
		'sName' => 'User',
		'email' => NULL,
		'telephone' => NULL,
		'uName' => 'ubadmin01',
		'passw' => 'DCSadmin-01',
		'uType' => 'admin'
	];

	$content = ''; # content to fill in placeholder

	if (uniqueUname($admin['uName'], $pdo) == "error") {
		$content .= htmlParagraph("ERROR initial admin could not be created.", False);
	} else if (uniqueUname($admin['uName'], $pdo)) {
		createInitialUser($admin, $pdo);
	}

	###############################################
	#LOGGING IN AND LOGGIN OUT
	$form = ''; # initializing log in form to be displayed

	# if log in button is pressed
	if (isset($_POST['login'])) {
		$form = LogIn::loginForm($pdo); # depending on if information entered was correct appropriate $form is returned
	} else { # at first clean log in form is displayed
		$form = LogIn::emptyLogin(); 
	}

	# after logging in log out form is displayed
	if (isset($_SESSION['uName']) and isset($_SESSION['passw'])) {
		$form = LogIn::loggedIn($pdo);
	}

	# when log out button is pressed
	if (isset($_POST['logout'])) {
		LogIn::logOut();
	} 

	#####################################################
	#CREATING NAV MENU AND CHOSING WHICH PAGE TO DISPLAY
	# defining NAV html
	$navigation = new Navigation;
	# returns navigation options and potential error message
	$chooseNavigation = $navigation -> definingNav($pdo, $nav);
	if (!empty($chooseNavigation[0])) {
		foreach ($chooseNavigation[0] as $key => $item) {
			$nav[$key] = $item;
		}
	}
	$content .= ($chooseNavigation[1] != '') ? $chooseNavigation[1] : '' ; # if error message was returned 

	#the method returns $headTitle, possible error message and file to be included
	$gettingFile = $navigation -> gettingFile($pdo, $nav);
	$headTitle = $gettingFile[0];
	if (!(empty($gettingFile[1]))) { # if error message was returned
		$content .= $gettingFile[1];
	} else {
		include $gettingFile[2]; # including the view
	}
	
} else {
	$content = "Database not connected.";
}

#######################################################
#BUILDING HTML PAGE TO DISPLAY
$placeholders = array(); #define array of HTML placeholders that are found in the template 
$placeholders[] = '[+title+]'; 
$placeholders[] = '[+heading+]';
$placeholders[] = '[+form+]';
$placeholders[] = '[+NAV+]';
$placeholders[] = '[+content+]';

$values = array(); #array of variables to replace the HTML placeholders with
$values[] = $headTitle;
$values[] = $viewHeading;
$values[] = $form;
$values[] = htmlNAVspe($nav); 
$values[] = $content;
#generate HTML 
$html = htmlTemplate($placeholders, $values, 'templates/page.html'); 
echo $html; 

?>
