<?php
$viewHeading = htmlHeading("Module results",2);
$content = '';
$tables = '';
$modules = ['dt', 'jv', 'p1'];
        
# checking if the databse is empty, to insert the information if it is
$checkIfEmpty = checkIfEmpty($pdo);	

if ($checkIfEmpty == 'True') {
	$content .= insertDataModuleResults($pdo);
} else if ($checkIfEmpty == 'error') {
	$content .= htmlParagraph("ERROR database could not be checked.", False);
} 	
	# creating tables to print out
	foreach ($modules as $module) {
		$table =  printOutModuleResults($module, $pdo);
		if ($table != 'error') {
			$tables .= $table;
		} else {
			$tables .= htmlParagraph("ERROR" . TitleOfResults($module) . "table was not printed", False);
		}
	}

	$placeholders[] = '[+tables+]';
	$values[] = $tables;

	$template = file_get_contents('html/moduleResults.html'); 
	$content .= str_replace($placeholders, $values, $template); # creating a page view

?>